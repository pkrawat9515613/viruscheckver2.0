import csv
import requests
import time

# Use your own VirusTotal API key
API_KEY = '065512cf543f353d9c8aaec25ff6d1b05ef042068e746b80d55f983a2b4b589e'
API_URL = 'https://www.virustotal.com/api/v3/ip_addresses/'

# Function to query VirusTotal API
def query_virustotal(ip_address):
    headers = {
        'x-apikey': API_KEY
    }
    
    try:
        response = requests.get(API_URL + ip_address, headers=headers)
        response.raise_for_status()  # Will raise an exception for 4xx/5xx responses
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error querying VirusTotal for IP {ip_address}: {e}")
        return None

# Function to process the CSV file and get the report
def process_csv(input_csv, output_csv):
    with open(input_csv, mode='r') as infile, open(output_csv, mode='w', newline='') as outfile:
        reader = csv.reader(infile)
        writer = csv.writer(outfile)

        # Write headers to output CSV
        writer.writerow(['IP Address', 'VirusTotal Report'])

        for row in reader:
            ip_address = row[0]  # Assuming the IP is in the first column
            print(f"Checking IP: {ip_address}")
            result = query_virustotal(ip_address)
            
            if result:
                # Extract relevant information from the response
                data = result.get('data', {})
                if 'attributes' in data:
                    report = data['attributes'].get('last_analysis_stats', {})
                    writer.writerow([ip_address, report])
                else:
                    writer.writerow([ip_address, 'No data available'])
            else:
                writer.writerow([ip_address, 'Error retrieving data'])

            # To avoid hitting API rate limits, add a short delay
            time.sleep(0)  # Adjust based on the rate limits of your API key

# Main function to trigger the process
if __name__ == '__main__':
    input_file = 'input_ips.csv'  # Replace with your input CSV file name
    output_file = 'output_report.csv'  # Replace with desired output CSV file name
    process_csv(input_file, output_file)
    print(f"IP address report has been saved to {output_file}")