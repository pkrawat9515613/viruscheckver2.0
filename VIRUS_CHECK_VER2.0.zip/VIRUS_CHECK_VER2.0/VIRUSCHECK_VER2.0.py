import csv
import requests
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# Use your own VirusTotal API key
API_KEY = '065512cf543f353d9c8aaec25ff6d1b05ef042068e746b80d55f983a2b4b589e'
API_URL = 'https://www.virustotal.com/api/v3/ip_addresses/'

# Function to query VirusTotal API
def query_virustotal(ip_address):
    headers = {'x-apikey': API_KEY}
    try:
        response = requests.get(API_URL + ip_address, headers=headers)
        response.raise_for_status()  # Will raise an exception for 4xx/5xx responses
        return response.json()
    except requests.exceptions.RequestException as e:
        return None

# Function to process the IPs in the list and generate the report
def process_ips():
    # Get the input file path from the user
    input_file = file_path.get()

    if not input_file:
        messagebox.showerror("Input Error", "Please select a CSV file.")
        return
    
    output_file = output_file_path.get()

    if not output_file:
        messagebox.showerror("Output Error", "Please specify an output file.")
        return
    
    try:
        with open(input_file, mode='r') as infile:
            reader = list(csv.reader(infile))  # Read all rows first
            total_ips = len(reader)  # Total number of IPs
            if total_ips == 0:
                messagebox.showerror("Empty File", "The input CSV file is empty.")
                return

            # Open output file for writing
            with open(output_file, mode='w', newline='') as outfile:
                writer = csv.writer(outfile)
                writer.writerow(['IP Address', 'Malicious', 'Harmless', 'Suspicious', 'Undetected', 'Timeouts', 'VirusTotal Link'])

                # Update progress bar
                progress_bar['maximum'] = total_ips
                progress_bar['value'] = 0
                progress_label.config(text="Processing 0%")
                root.update_idletasks()

                for index, row in enumerate(reader):
                    ip_address = row[0]
                    result = query_virustotal(ip_address)

                    if result:
                        data = result.get('data', {})
                        if 'attributes' in data:
                            report = data['attributes'].get('last_analysis_stats', {})
                            malicious = report.get('malicious', 'N/A')
                            harmless = report.get('harmless', 'N/A')
                            suspicious = report.get('suspicious', 'N/A')
                            undetected = report.get('undetected', 'N/A')
                            timeouts = report.get('timeout', 'N/A')
                        else:
                            malicious = harmless = suspicious = undetected = timeouts = 'No data available'
                    else:
                        malicious = harmless = suspicious = undetected = timeouts = 'Error retrieving data'

                    # Filter condition: Include only IPs with malicious count > 0 or error report
                    if (malicious != 'N/A' and int(malicious) > 0) or malicious == 'Error retrieving data':
                        # VirusTotal link
                        virustotal_link = f'https://www.virustotal.com/gui/ip-address/{ip_address}'

                        # Write data to the output CSV
                        writer.writerow([ip_address, malicious, harmless, suspicious, undetected, timeouts, virustotal_link])

                    # Update progress bar
                    progress_bar['value'] = index + 1
                    percentage = (index + 1) / total_ips * 100
                    progress_label.config(text=f"Processing {int(percentage)}%")
                    root.update_idletasks()

                    # To avoid hitting API rate limits, add a short delay
                    time.sleep(0)  # Adjust delay based on your rate limits

        messagebox.showinfo("Success", f"IP address report has been saved to {output_file}")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

# Function to browse and select the input file
def browse_input_file():
    file = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    file_path.set(file)

# Function to browse and select the output file
def browse_output_file():
    file = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
    output_file_path.set(file)

# Main Tkinter window setup
root = tk.Tk()
root.title("VirusTotal IP Report Generator")

# Setting up StringVar for storing file paths
file_path = tk.StringVar()
output_file_path = tk.StringVar()

# Creating the input file selection
input_frame = ttk.LabelFrame(root, text="Select Input CSV File", padding="10")
input_frame.grid(row=0, column=0, padx=10, pady=10, sticky="w")

input_entry = ttk.Entry(input_frame, textvariable=file_path, width=40)
input_entry.grid(row=0, column=0, padx=5)
input_browse_button = ttk.Button(input_frame, text="Browse", command=browse_input_file)
input_browse_button.grid(row=0, column=1, padx=5)

# Creating the output file selection
output_frame = ttk.LabelFrame(root, text="Select Output CSV File", padding="10")
output_frame.grid(row=1, column=0, padx=10, pady=10, sticky="w")

output_entry = ttk.Entry(output_frame, textvariable=output_file_path, width=40)
output_entry.grid(row=0, column=0, padx=5)
output_browse_button = ttk.Button(output_frame, text="Browse", command=browse_output_file)
output_browse_button.grid(row=0, column=1, padx=5)

# Create Progress Bar
progress_frame = ttk.LabelFrame(root, text="Progress", padding="10")
progress_frame.grid(row=2, column=0, padx=10, pady=10, sticky="w")

progress_bar = ttk.Progressbar(progress_frame, orient="horizontal", length=400, mode="determinate")
progress_bar.grid(row=0, column=0, padx=5)

progress_label = ttk.Label(progress_frame, text="Processing 0%")
progress_label.grid(row=1, column=0, padx=5)

# Process Button
process_button = ttk.Button(root, text="Generate Report", command=process_ips)
process_button.grid(row=3, column=0, padx=10, pady=20)

# Start the Tkinter event loop
root.mainloop()